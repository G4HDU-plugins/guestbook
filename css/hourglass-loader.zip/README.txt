A Pen created at CodePen.io. You can find this one at http://codepen.io/tomhazledine/pen/BKrXwJ.

 Animated hourglass loading graphic. Inline SVG styled with SASS